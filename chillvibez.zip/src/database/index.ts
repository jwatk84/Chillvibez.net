import { DataSource } from "typeorm";
import StatsPlayer from "../models/StatsPlayer";

const dataSource = new DataSource({
    type: 'mariadb',
    host: process.env.DB_HOST,
    port: +process.env.DB_PORT,
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DATABASE,
    entities: [StatsPlayer]
});

dataSource.initialize()
.then(() => console.log('Data Source has been initialized!'))
.catch((error) => console.error('Error during Data Source initialization', error));

export default dataSource;