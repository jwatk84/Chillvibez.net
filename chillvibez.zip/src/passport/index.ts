import passport from 'passport';
import steam from './strategies/SteamStrat';

passport.serializeUser((user, done) => {
    done(null, user);
})

passport.deserializeUser((obj, done) => {
    done(null, obj)
});

// Steam Strat
passport.use(steam);

export default passport;