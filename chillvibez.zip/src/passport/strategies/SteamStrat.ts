import { Strategy } from "passport-steam";

const strategy = new Strategy({
    returnURL: 'http://localhost:3000/auth/steam/return',
    realm: 'http://localhost:3000/',
    apiKey: process.env.STEAM_API
}, async (identifier: any, profile: any, done: any) => {
    profile.identifier = identifier;
    done(null, profile);
});

export default strategy;