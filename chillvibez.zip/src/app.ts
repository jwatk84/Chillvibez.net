import 'reflect-metadata';
import * as dotenv from 'dotenv';

dotenv.config();

import express from 'express';
import morgan from 'morgan';
import { json, urlencoded } from 'body-parser';
import cors from 'cors';
import session from 'express-session';
import helmet from 'helmet';
import passport from './passport';
import path from 'path';

import routes from './routes';

const app = express();

// The fiels within the public folder can be accessed by anyone
app.use('/', express.static(path.join(__dirname, '../public')));

// Intended to log requests
app.use(morgan('combined'));

// Parse requests to include application/json and application/x-www-form-urlencoded
app.use(json());
app.use(urlencoded({ extended: true }));

// Change to prevent outside usage
app.use(cors());

// Adds req.session
app.use(session({
    secret: process.env.SESSION_SECRET || 'secret_super_duper_code',
    resave: true,
    saveUninitialized: false,
    cookie: { maxAge: 1000000000 }
}));

// Initializes and allows usage of passportjs for authentication
app.use(passport.initialize());
app.use(passport.session());

// Secures application by adding various HTTP headers
app.use(helmet.contentSecurityPolicy({
    useDefaults: true,
    directives: {
        "img-src": ["'self'", "https: data"],
        "script-src": ["'self'", "https: data"]
    }
}));

app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));

// Express Router
app.use(routes);

export default app;