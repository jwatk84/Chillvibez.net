import { Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('stats_player')
export default class StatsPlayer {
    @PrimaryGeneratedColumn()
    id: number
}