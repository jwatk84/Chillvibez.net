export const login = (req: any, res: any) => {};

export const loginReturn = (req: any, res: any) => {
    // Successful authentication
    res.redirect('/');
};