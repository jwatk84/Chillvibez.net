import { Router } from 'express';
import passport from '../../passport';
const router = Router();

router.get('/steam', passport.authenticate('steam'));

router.get('/steam/return',
    passport.authenticate('steam', { successRedirect: '/', failureRedirect: '/login' }));

export default router;