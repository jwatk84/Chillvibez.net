import { Router } from 'express';
import dataSource from '../database';
import Steam from './strat/Steam';
import StatsPlayer from '../models/StatsPlayer';
const router = Router();

router.use('/auth', Steam);

router.get('/', function(req, res) {
    res.render('index', { profile: req.user ?? undefined});
});

router.get('/servers', function(req, res) {
    res.render('servers', { profile: req.user ?? undefined});
});

router.get('/leaderboard',  async function(req, res) {
    const data = await dataSource.manager
    .createQueryBuilder(StatsPlayer, 'stats_player')
    .select(['UserID', 'Name', 'PVPKills', 'Deaths', 'KDR'])
    .limit(30);
    res.render('leaderboards', { profile: req.user ?? undefined, data: data});
});

export default router;